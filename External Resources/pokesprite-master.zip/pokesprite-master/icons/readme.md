**IMPORTANT NOTICE:**

All the files in this directory structure are *legacy icons* and will likely not be updated anymore. See the readme file for where to find the most up-to-date icons.

Numerous websites are linking to these icons directly, including a lot of Google Sheets pages (e.g. for traders), which is why these are being kept here instead of deleted or moved.
